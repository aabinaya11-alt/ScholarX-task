// FitTrack Design System

export const colors = {
  // Brand
  primary: "#FF4D00",
  primaryDark: "#D93D00",
  primaryLight: "#FFF0EB",
  primaryGlow: "rgba(255, 77, 0, 0.18)",

  // Neutrals
  black: "#0D0D0D",
  gray900: "#1A1A1A",
  gray800: "#2C2C2C",
  gray600: "#6B6B6B",
  gray400: "#A3A3A3",
  gray200: "#E8E8E8",
  gray100: "#F5F5F5",
  white: "#FFFFFF",

  // Semantic
  success: "#22C55E",
  successLight: "#F0FDF4",
  warning: "#F59E0B",
  warningLight: "#FFFBEB",
  info: "#3B82F6",
  infoLight: "#EFF6FF",

  // Surface
  surface: "#FFFFFF",
  surfaceRaised: "#FAFAFA",
  overlay: "rgba(13, 13, 13, 0.6)",

  // Chart colors
  chartOrange: "#FF4D00",
  chartBlue: "#3B82F6",
  chartGreen: "#22C55E",
  chartPurple: "#A855F7",
};

export const radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 28,
  full: 9999,
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const shadow = {
  sm: "0 1px 3px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.06)",
  md: "0 4px 12px rgba(0,0,0,0.08), 0 2px 4px rgba(0,0,0,0.05)",
  lg: "0 12px 32px rgba(0,0,0,0.10), 0 4px 8px rgba(0,0,0,0.06)",
  primary: "0 8px 24px rgba(255, 77, 0, 0.35)",
  primarySm: "0 4px 12px rgba(255, 77, 0, 0.25)",
};

export const transition = {
  spring: { type: "spring" as const, stiffness: 400, damping: 38 },
  springBouncy: { type: "spring" as const, stiffness: 320, damping: 24 },
  ease: { duration: 0.22, ease: [0.4, 0, 0.2, 1] as const },
  fade: { duration: 0.18 },
};
