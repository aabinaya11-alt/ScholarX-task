import { useState, useRef } from "react";
import { AnimatePresence, motion } from "motion/react";
import { PhoneShell } from "./PhoneShell";
import { Screen1Welcome } from "./screens/Screen1Welcome";
import {
  Screen2TrackWorkouts,
  Screen3PersonalizedPlans,
  Screen4ProgressAnalytics,
} from "./screens/FeatureScreens";
import { Screen5Auth } from "./screens/Screen5Auth";
import { Screen6Goals } from "./screens/Screen6Goals";
import { Screen7Dashboard } from "./screens/Screen7Dashboard";
import { colors } from "./ds";

type ScreenId =
  | "welcome"
  | "feature1"
  | "feature2"
  | "feature3"
  | "auth"
  | "goals"
  | "dashboard";

interface ScreenEntry {
  id: ScreenId;
  statusLight?: boolean;
}

const FLOW: ScreenEntry[] = [
  { id: "welcome", statusLight: true },
  { id: "feature1" },
  { id: "feature2" },
  { id: "feature3" },
  { id: "auth" },
  { id: "goals" },
  { id: "dashboard" },
];

const SCREEN_LABELS: Record<ScreenId, string> = {
  welcome: "1. Welcome",
  feature1: "2. Track Workouts",
  feature2: "3. Personalized Plans",
  feature3: "4. Progress Analytics",
  auth: "5. Sign Up / Login",
  goals: "6. Goal Selection",
  dashboard: "7. Home Dashboard",
};

export function OnboardingFlow() {
  const [index, setIndex] = useState(0);
  const [direction, setDirection] = useState(1);

  const current = FLOW[index];

  const go = (target: number) => {
    if (target < 0 || target >= FLOW.length) return;
    setDirection(target > index ? 1 : -1);
    setIndex(target);
  };
  const next = () => go(index + 1);
  const back = () => go(index - 1);
  const skipToAuth = () => go(FLOW.findIndex((s) => s.id === "auth"));
  const restart = () => { setDirection(-1); setIndex(0); };

  const variants = {
    enter: (dir: number) => ({ x: dir * 40, opacity: 0 }),
    center: { x: 0, opacity: 1 },
    exit: (dir: number) => ({ x: dir * -40, opacity: 0 }),
  };

  return (
    <div
      className="w-full h-full flex flex-col items-center justify-center gap-8"
      style={{ background: "#EDEBE6", overflowY: "auto", padding: "32px 16px" }}
    >
      {/* Screen label */}
      <div className="flex flex-col items-center gap-3">
        <div className="flex items-center gap-2">
          {FLOW.map((s, i) => (
            <button
              key={s.id}
              onClick={() => go(i)}
              title={SCREEN_LABELS[s.id]}
              style={{
                width: i === index ? 28 : 8,
                height: 8,
                borderRadius: 99,
                background: i === index ? colors.primary : i < index ? colors.gray400 : colors.gray200,
                border: "none",
                cursor: "pointer",
                transition: "all 0.25s ease",
                padding: 0,
              }}
            />
          ))}
        </div>
        <p
          style={{
            color: colors.gray600,
            fontSize: 13,
            fontWeight: 600,
            letterSpacing: "0.02em",
          }}
        >
          {SCREEN_LABELS[current.id]}
        </p>
      </div>

      {/* Phone */}
      <PhoneShell statusBarLight={current.statusLight}>
        <AnimatePresence mode="wait" custom={direction} initial={false}>
          <motion.div
            key={current.id}
            custom={direction}
            variants={variants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ type: "spring", stiffness: 420, damping: 40 }}
            style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column" }}
          >
            {current.id === "welcome" && (
              <Screen1Welcome onGetStarted={next} onLogin={skipToAuth} />
            )}
            {current.id === "feature1" && (
              <Screen2TrackWorkouts onNext={next} onSkip={skipToAuth} slideIndex={0} />
            )}
            {current.id === "feature2" && (
              <Screen3PersonalizedPlans onNext={next} onSkip={skipToAuth} />
            )}
            {current.id === "feature3" && (
              <Screen4ProgressAnalytics onNext={next} onSkip={skipToAuth} />
            )}
            {current.id === "auth" && (
              <Screen5Auth onSignUp={next} onBack={back} />
            )}
            {current.id === "goals" && (
              <Screen6Goals onNext={next} onBack={back} />
            )}
            {current.id === "dashboard" && (
              <Screen7Dashboard onRestart={restart} />
            )}
          </motion.div>
        </AnimatePresence>
      </PhoneShell>

      {/* Arrow nav */}
      <div className="flex items-center gap-4">
        {index > 0 && (
          <button
            onClick={back}
            style={{
              height: 40,
              paddingLeft: 20,
              paddingRight: 20,
              borderRadius: 99,
              background: colors.white,
              border: `1.5px solid ${colors.gray200}`,
              color: colors.gray800,
              fontSize: 13,
              fontWeight: 600,
              cursor: "pointer",
              boxShadow: "0 1px 4px rgba(0,0,0,0.07)",
            }}
          >
            ← Previous
          </button>
        )}
        {index < FLOW.length - 1 && (
          <button
            onClick={next}
            style={{
              height: 40,
              paddingLeft: 20,
              paddingRight: 20,
              borderRadius: 99,
              background: colors.primary,
              border: "none",
              color: colors.white,
              fontSize: 13,
              fontWeight: 700,
              cursor: "pointer",
              boxShadow: "0 4px 12px rgba(255,77,0,0.3)",
            }}
          >
            Next →
          </button>
        )}
      </div>
    </div>
  );
}
