import { ReactNode } from "react";
import { colors } from "./ds";

interface Props {
  children: ReactNode;
  statusBarLight?: boolean;
}

export function PhoneShell({ children, statusBarLight = false }: Props) {
  const textColor = statusBarLight ? colors.white : colors.black;

  return (
    <div
      className="relative overflow-hidden flex flex-col select-none"
      style={{
        width: 393,
        height: 852,
        background: colors.white,
        borderRadius: 52,
        boxShadow:
          "0 0 0 10px #1a1a1a, 0 0 0 12px #2c2c2c, 0 48px 96px rgba(0,0,0,0.28), 0 12px 32px rgba(0,0,0,0.14)",
        flexShrink: 0,
      }}
    >
      {/* Dynamic Island */}
      <div
        className="absolute left-1/2 -translate-x-1/2 z-50"
        style={{ top: 12 }}
      >
        <div
          style={{
            width: 126,
            height: 36,
            background: "#000",
            borderRadius: 20,
          }}
        />
      </div>

      {/* Status bar */}
      <div
        className="relative z-40 flex items-center justify-between shrink-0"
        style={{ paddingLeft: 28, paddingRight: 28, paddingTop: 16, height: 54 }}
      >
        <span style={{ fontSize: 15, fontWeight: 600, color: textColor }}>9:41</span>
        <div style={{ width: 126 }} /> {/* Dynamic Island spacer */}
        {/* Battery + signal icons */}
        <div className="flex items-center gap-1.5">
          <div style={{ display: "flex", gap: 2 }}>
            {[3, 4, 5].map((h, i) => (
              <div
                key={i}
                style={{
                  width: 3,
                  height: h,
                  background: textColor,
                  borderRadius: 1,
                  opacity: 0.85,
                  alignSelf: "flex-end",
                }}
              />
            ))}
          </div>
          <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
            <rect x="0" y="0" width="14" height="12" rx="2.5" stroke={textColor} strokeWidth="1.2" strokeOpacity="0.85" />
            <rect x="14.5" y="3.5" width="1.5" height="5" rx="1" fill={textColor} fillOpacity="0.5" />
            <rect x="1.5" y="1.5" width="9" height="9" rx="1.2" fill={textColor} fillOpacity="0.85" />
          </svg>
        </div>
      </div>

      {/* Screen content */}
      <div className="flex-1 flex flex-col relative overflow-hidden">
        {children}
      </div>

      {/* Home indicator */}
      <div className="flex justify-center shrink-0 pb-2 pt-1">
        <div
          style={{
            width: 134,
            height: 5,
            background: colors.black,
            borderRadius: 3,
            opacity: 0.2,
          }}
        />
      </div>
    </div>
  );
}
