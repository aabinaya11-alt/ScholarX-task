import { motion, AnimatePresence } from "motion/react";
import { useState, useRef } from "react";
import { colors, shadow, radius, transition } from "../ds";
import { ChevronRight, Activity, MapPin, Timer, Dumbbell, Brain, Flame, BarChart2, TrendingUp, Award } from "lucide-react";

// ─── Shared subcomponents ────────────────────────────────────────────────────

function ProgressDots({ total, current }: { total: number; current: number }) {
  return (
    <div className="flex items-center gap-2">
      {Array.from({ length: total }).map((_, i) => (
        <motion.div
          key={i}
          animate={{
            width: i === current ? 28 : 8,
            background: i === current ? colors.primary : colors.gray200,
          }}
          transition={transition.ease}
          style={{ height: 8, borderRadius: 99 }}
        />
      ))}
    </div>
  );
}

// ─── Screen 2: Track Workouts ─────────────────────────────────────────────────

const workoutTypes = [
  { icon: "🏃", label: "Running", cal: "420 cal", time: "38 min", color: "#FFF0EB", accent: colors.primary },
  { icon: "🏋️", label: "Strength", cal: "310 cal", time: "45 min", color: "#EFF6FF", accent: "#3B82F6" },
  { icon: "🚴", label: "Cycling", cal: "580 cal", time: "55 min", color: "#F0FDF4", accent: "#22C55E" },
  { icon: "🧘", label: "Yoga", cal: "180 cal", time: "30 min", color: "#FDF4FF", accent: "#A855F7" },
];

const liveMetrics = [
  { icon: Timer, label: "Duration", value: "38:24", unit: "" },
  { icon: Flame, label: "Calories", value: "420", unit: "kcal" },
  { icon: Activity, label: "Heart rate", value: "148", unit: "bpm" },
  { icon: MapPin, label: "Distance", value: "5.2", unit: "km" },
];

export function Screen2TrackWorkouts({
  onNext,
  onSkip,
  slideIndex,
}: {
  onNext: () => void;
  onSkip: () => void;
  slideIndex: number;
}) {
  return (
    <div className="flex flex-col h-full" style={{ background: colors.white }}>
      {/* Top nav */}
      <div className="flex items-center justify-between px-6 pt-4 pb-2 shrink-0">
        <ProgressDots total={3} current={0} />
        <button
          onClick={onSkip}
          style={{ color: colors.gray400, fontSize: 15, fontWeight: 500, background: "none", border: "none", cursor: "pointer" }}
        >
          Skip
        </button>
      </div>

      {/* Illustration area */}
      <div
        className="mx-6 shrink-0"
        style={{
          borderRadius: 24,
          background: "linear-gradient(135deg, #1a0800 0%, #ff4d00 100%)",
          padding: 24,
          marginBottom: 20,
          position: "relative",
          overflow: "hidden",
        }}
      >
        {/* Ambient circle */}
        <div
          style={{
            position: "absolute",
            width: 200,
            height: 200,
            borderRadius: "50%",
            background: "rgba(255,140,90,0.25)",
            top: -60,
            right: -60,
          }}
        />

        {/* Live workout card mock */}
        <div style={{ marginBottom: 16 }}>
          <p style={{ color: "rgba(255,255,255,0.6)", fontSize: 12, fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 4 }}>
            Live workout
          </p>
          <p style={{ color: colors.white, fontSize: 22, fontWeight: 800, letterSpacing: "-0.02em" }}>
            🏃 Morning Run
          </p>
        </div>

        {/* Metrics grid */}
        <div className="grid grid-cols-2 gap-3">
          {liveMetrics.map((m) => (
            <div
              key={m.label}
              style={{
                background: "rgba(255,255,255,0.12)",
                borderRadius: 14,
                padding: "10px 14px",
                backdropFilter: "blur(8px)",
              }}
            >
              <m.icon size={14} color="rgba(255,255,255,0.6)" style={{ marginBottom: 4 }} />
              <p style={{ color: colors.white, fontSize: 20, fontWeight: 800, lineHeight: 1 }}>
                {m.value}
                <span style={{ fontSize: 11, fontWeight: 500, opacity: 0.7, marginLeft: 3 }}>{m.unit}</span>
              </p>
              <p style={{ color: "rgba(255,255,255,0.55)", fontSize: 11, marginTop: 2 }}>{m.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Workout type chips */}
      <div className="px-6 flex gap-2 overflow-x-auto shrink-0" style={{ paddingBottom: 4 }}>
        {workoutTypes.map((w, i) => (
          <motion.div
            key={w.label}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.07 }}
            style={{
              background: w.color,
              borderRadius: 12,
              padding: "8px 14px",
              display: "flex",
              alignItems: "center",
              gap: 6,
              flexShrink: 0,
            }}
          >
            <span style={{ fontSize: 16 }}>{w.icon}</span>
            <div>
              <p style={{ fontSize: 12, fontWeight: 700, color: colors.black }}>{w.label}</p>
              <p style={{ fontSize: 11, color: colors.gray600 }}>{w.cal}</p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Text content */}
      <div className="flex-1 flex flex-col justify-end px-6 pb-6">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <p style={{ color: colors.primary, fontSize: 12, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 8 }}>
            Track workouts
          </p>
          <h2 style={{ fontSize: 30, fontWeight: 800, color: colors.black, lineHeight: 1.15, letterSpacing: "-0.025em", marginBottom: 10 }}>
            Every rep counts.{"\n"}We're watching.
          </h2>
          <p style={{ color: colors.gray600, fontSize: 15, lineHeight: 1.6, marginBottom: 28 }}>
            Log over 80 workout types with auto-tracking for distance, heart rate, and calories in real time.
          </p>
          <button
            onClick={onNext}
            style={{
              width: "100%",
              height: 56,
              borderRadius: 16,
              background: colors.primary,
              color: colors.white,
              fontSize: 17,
              fontWeight: 700,
              border: "none",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
              boxShadow: shadow.primary,
            }}
          >
            Next <ChevronRight size={20} />
          </button>
        </motion.div>
      </div>
    </div>
  );
}

// ─── Screen 3: Personalized Plans ────────────────────────────────────────────

const planCards = [
  {
    title: "8-Week Fat Burn",
    subtitle: "Intermediate · 5 days/week",
    tag: "Trending 🔥",
    tagColor: colors.primaryLight,
    tagText: colors.primary,
    progress: 0.42,
    emoji: "💪",
    bg: "#FFF0EB",
  },
  {
    title: "Strength Builder",
    subtitle: "All levels · 3 days/week",
    tag: "Top rated ⭐",
    tagColor: "#FFFBEB",
    tagText: "#D97706",
    progress: 0.0,
    emoji: "🏋️",
    bg: "#EFF6FF",
  },
  {
    title: "5K Run Training",
    subtitle: "Beginner · 4 days/week",
    tag: "New 🆕",
    tagColor: "#F0FDF4",
    tagText: "#16A34A",
    progress: 0.0,
    emoji: "🏃",
    bg: "#F0FDF4",
  },
];

function MiniProgressBar({ value, color }: { value: number; color: string }) {
  return (
    <div style={{ height: 4, background: colors.gray200, borderRadius: 99, overflow: "hidden" }}>
      <motion.div
        initial={{ width: 0 }}
        animate={{ width: `${value * 100}%` }}
        transition={{ delay: 0.4, duration: 0.6, ease: "easeOut" }}
        style={{ height: "100%", background: color, borderRadius: 99 }}
      />
    </div>
  );
}

export function Screen3PersonalizedPlans({ onNext, onSkip }: { onNext: () => void; onSkip: () => void }) {
  return (
    <div className="flex flex-col h-full" style={{ background: colors.gray100 }}>
      {/* Top nav */}
      <div
        className="flex items-center justify-between px-6 pt-4 pb-4 shrink-0"
        style={{ background: colors.white }}
      >
        <ProgressDots total={3} current={1} />
        <button
          onClick={onSkip}
          style={{ color: colors.gray400, fontSize: 15, fontWeight: 500, background: "none", border: "none", cursor: "pointer" }}
        >
          Skip
        </button>
      </div>

      {/* Header */}
      <div style={{ background: colors.white, paddingLeft: 24, paddingRight: 24, paddingBottom: 20 }}>
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <p style={{ color: colors.primary, fontSize: 12, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 6 }}>
            Personalized plans
          </p>
          <h2 style={{ fontSize: 28, fontWeight: 800, color: colors.black, lineHeight: 1.2, letterSpacing: "-0.02em", marginBottom: 6 }}>
            Your coach, in your pocket
          </h2>
          <p style={{ color: colors.gray600, fontSize: 14, lineHeight: 1.55 }}>
            AI-crafted programs built around your schedule, fitness level, and goals. Updated as you improve.
          </p>
        </motion.div>
      </div>

      {/* Plan cards */}
      <div
        className="flex-1 overflow-y-auto"
        style={{ padding: "16px 20px", display: "flex", flexDirection: "column", gap: 12 }}
      >
        {planCards.map((p, i) => (
          <motion.div
            key={p.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 + 0.15 }}
            style={{
              background: colors.white,
              borderRadius: 20,
              padding: 18,
              boxShadow: shadow.sm,
              display: "flex",
              gap: 14,
              alignItems: "flex-start",
            }}
          >
            <div
              style={{
                width: 52,
                height: 52,
                borderRadius: 14,
                background: p.bg,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 24,
                flexShrink: 0,
              }}
            >
              {p.emoji}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="flex items-start justify-between gap-2" style={{ marginBottom: 4 }}>
                <p style={{ fontWeight: 700, color: colors.black, fontSize: 15, lineHeight: 1.3 }}>{p.title}</p>
                <span
                  style={{
                    background: p.tagColor,
                    color: p.tagText,
                    fontSize: 11,
                    fontWeight: 600,
                    padding: "3px 8px",
                    borderRadius: 99,
                    whiteSpace: "nowrap",
                    flexShrink: 0,
                  }}
                >
                  {p.tag}
                </span>
              </div>
              <p style={{ color: colors.gray600, fontSize: 12, marginBottom: p.progress > 0 ? 8 : 0 }}>
                {p.subtitle}
              </p>
              {p.progress > 0 && (
                <>
                  <MiniProgressBar value={p.progress} color={colors.primary} />
                  <p style={{ color: colors.primary, fontSize: 11, fontWeight: 600, marginTop: 4 }}>
                    {Math.round(p.progress * 100)}% complete
                  </p>
                </>
              )}
            </div>
          </motion.div>
        ))}

        {/* Spacer for button */}
        <div style={{ height: 80 }} />
      </div>

      {/* Fixed bottom CTA */}
      <div
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          padding: "16px 24px 20px",
          background: "linear-gradient(to top, white 60%, transparent)",
        }}
      >
        <button
          onClick={onNext}
          style={{
            width: "100%",
            height: 56,
            borderRadius: 16,
            background: colors.primary,
            color: colors.white,
            fontSize: 17,
            fontWeight: 700,
            border: "none",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            boxShadow: shadow.primary,
          }}
        >
          Next <ChevronRight size={20} />
        </button>
      </div>
    </div>
  );
}

// ─── Screen 4: Progress Analytics ────────────────────────────────────────────

const weekBars = [
  { day: "M", val: 0.6, active: false },
  { day: "T", val: 0.85, active: false },
  { day: "W", val: 0.45, active: false },
  { day: "T", val: 1.0, active: true },
  { day: "F", val: 0.7, active: false },
  { day: "S", val: 0.5, active: false },
  { day: "S", val: 0.3, active: false },
];

const analyticsStats = [
  { icon: TrendingUp, label: "Streak", value: "14 days", color: colors.primary, bg: colors.primaryLight },
  { icon: Flame, label: "This week", value: "2,840 cal", color: "#F59E0B", bg: "#FFFBEB" },
  { icon: Award, label: "Badges", value: "7 earned", color: "#A855F7", bg: "#FDF4FF" },
  { icon: BarChart2, label: "PRs set", value: "3 this month", color: "#22C55E", bg: "#F0FDF4" },
];

export function Screen4ProgressAnalytics({ onNext, onSkip }: { onNext: () => void; onSkip: () => void }) {
  return (
    <div className="flex flex-col h-full" style={{ background: colors.white }}>
      {/* Top nav */}
      <div className="flex items-center justify-between px-6 pt-4 pb-3 shrink-0">
        <ProgressDots total={3} current={2} />
        <button
          onClick={onSkip}
          style={{ color: colors.gray400, fontSize: 15, fontWeight: 500, background: "none", border: "none", cursor: "pointer" }}
        >
          Skip
        </button>
      </div>

      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        style={{ paddingLeft: 24, paddingRight: 24, marginBottom: 20 }}
      >
        <p style={{ color: colors.primary, fontSize: 12, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 6 }}>
          Progress analytics
        </p>
        <h2 style={{ fontSize: 28, fontWeight: 800, color: colors.black, lineHeight: 1.2, letterSpacing: "-0.02em", marginBottom: 6 }}>
          See how far you've come
        </h2>
        <p style={{ color: colors.gray600, fontSize: 14, lineHeight: 1.55 }}>
          Beautiful charts. Real insights. Watch your effort compound into results week over week.
        </p>
      </motion.div>

      {/* Weekly chart card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.15 }}
        style={{
          marginLeft: 20,
          marginRight: 20,
          background: colors.black,
          borderRadius: 24,
          padding: 20,
          marginBottom: 16,
        }}
      >
        <div className="flex items-center justify-between" style={{ marginBottom: 4 }}>
          <div>
            <p style={{ color: "rgba(255,255,255,0.55)", fontSize: 11, fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase" }}>
              Weekly calories
            </p>
            <p style={{ color: colors.white, fontSize: 28, fontWeight: 800, letterSpacing: "-0.02em" }}>
              2,840
              <span style={{ fontSize: 13, fontWeight: 500, opacity: 0.55, marginLeft: 4 }}>kcal</span>
            </p>
          </div>
          <div
            style={{
              background: "rgba(34,197,94,0.15)",
              borderRadius: 99,
              padding: "4px 10px",
              display: "flex",
              alignItems: "center",
              gap: 4,
            }}
          >
            <TrendingUp size={12} color="#22C55E" />
            <span style={{ color: "#22C55E", fontSize: 12, fontWeight: 700 }}>+18%</span>
          </div>
        </div>

        {/* Bar chart */}
        <div className="flex items-end gap-2" style={{ height: 80, marginTop: 16 }}>
          {weekBars.map((b, i) => (
            <div key={i} className="flex flex-col items-center flex-1 gap-1">
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: b.val * 64, opacity: 1 }}
                transition={{ delay: i * 0.06 + 0.3, ...transition.spring }}
                style={{
                  width: "100%",
                  borderRadius: 6,
                  background: b.active
                    ? colors.primary
                    : "rgba(255,255,255,0.18)",
                }}
              />
              <span style={{ color: "rgba(255,255,255,0.45)", fontSize: 10, fontWeight: 600 }}>{b.day}</span>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Stats grid */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 10,
          paddingLeft: 20,
          paddingRight: 20,
          marginBottom: 20,
        }}
      >
        {analyticsStats.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 + 0.4 }}
            style={{
              background: s.bg,
              borderRadius: 16,
              padding: "14px 16px",
            }}
          >
            <s.icon size={18} color={s.color} style={{ marginBottom: 6 }} />
            <p style={{ fontSize: 16, fontWeight: 800, color: colors.black, lineHeight: 1 }}>{s.value}</p>
            <p style={{ fontSize: 11, color: colors.gray600, marginTop: 3 }}>{s.label}</p>
          </motion.div>
        ))}
      </div>

      {/* CTA */}
      <div style={{ paddingLeft: 20, paddingRight: 20 }}>
        <motion.button
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.55 }}
          onClick={onNext}
          style={{
            width: "100%",
            height: 56,
            borderRadius: 16,
            background: colors.primary,
            color: colors.white,
            fontSize: 17,
            fontWeight: 700,
            border: "none",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            boxShadow: shadow.primary,
          }}
        >
          Create my account <ChevronRight size={20} />
        </motion.button>
      </div>
    </div>
  );
}
