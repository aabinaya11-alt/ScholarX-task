import { useState } from "react";
import { motion } from "motion/react";
import { colors, shadow, transition } from "../ds";
import { ChevronRight, ArrowLeft } from "lucide-react";

interface Props {
  onNext: () => void;
  onBack: () => void;
}

const goals = [
  {
    id: "lose_weight",
    emoji: "🔥",
    title: "Lose weight",
    subtitle: "Burn fat, reduce body weight",
    bg: "#FFF0EB",
    accent: colors.primary,
  },
  {
    id: "build_muscle",
    emoji: "💪",
    title: "Build muscle",
    subtitle: "Gain strength and lean mass",
    bg: "#EFF6FF",
    accent: "#3B82F6",
  },
  {
    id: "improve_endurance",
    emoji: "🏃",
    title: "Improve endurance",
    subtitle: "Run farther, breathe easier",
    bg: "#F0FDF4",
    accent: "#22C55E",
  },
  {
    id: "stay_active",
    emoji: "⚡",
    title: "Stay active",
    subtitle: "Build consistent healthy habits",
    bg: "#FFFBEB",
    accent: "#F59E0B",
  },
  {
    id: "reduce_stress",
    emoji: "🧘",
    title: "Reduce stress",
    subtitle: "Mobility, recovery, mindfulness",
    bg: "#FDF4FF",
    accent: "#A855F7",
  },
  {
    id: "compete",
    emoji: "🏅",
    title: "Compete & perform",
    subtitle: "Train for races and events",
    bg: "#F0FDF4",
    accent: "#0EA5E9",
  },
];

const fitnessLevels = [
  { id: "beginner", label: "Beginner", sub: "Just starting out" },
  { id: "intermediate", label: "Intermediate", sub: "Some experience" },
  { id: "advanced", label: "Advanced", sub: "Seasoned athlete" },
];

const daysPerWeek = [2, 3, 4, 5, 6];

export function Screen6Goals({ onNext, onBack }: Props) {
  const [selectedGoal, setSelectedGoal] = useState<string | null>(null);
  const [level, setLevel] = useState<string | null>(null);
  const [days, setDays] = useState<number | null>(null);

  const canContinue = selectedGoal !== null && level !== null && days !== null;

  return (
    <div className="flex flex-col h-full" style={{ background: colors.white }}>
      {/* Top nav */}
      <div className="flex items-center gap-4 px-6 pt-4 pb-2 shrink-0">
        <button
          onClick={onBack}
          style={{
            width: 36,
            height: 36,
            borderRadius: 10,
            background: colors.gray100,
            border: "none",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            cursor: "pointer",
          }}
        >
          <ArrowLeft size={18} color={colors.gray800} />
        </button>
        {/* Step progress bar */}
        <div style={{ flex: 1, height: 4, background: colors.gray200, borderRadius: 99 }}>
          <motion.div
            animate={{ width: canContinue ? "100%" : selectedGoal ? "50%" : "15%" }}
            transition={transition.ease}
            style={{ height: "100%", background: colors.primary, borderRadius: 99 }}
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pb-24">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          style={{ paddingLeft: 24, paddingRight: 24, paddingTop: 16, marginBottom: 24 }}
        >
          <p
            style={{
              color: colors.primary,
              fontSize: 12,
              fontWeight: 700,
              letterSpacing: "0.1em",
              textTransform: "uppercase",
              marginBottom: 8,
            }}
          >
            Step 6 of 7
          </p>
          <h2
            style={{
              fontSize: 28,
              fontWeight: 800,
              color: colors.black,
              lineHeight: 1.2,
              letterSpacing: "-0.025em",
              marginBottom: 6,
            }}
          >
            What's your main goal?
          </h2>
          <p style={{ color: colors.gray600, fontSize: 14, lineHeight: 1.55 }}>
            We'll build a personalized plan around it.
          </p>
        </motion.div>

        {/* Goal grid */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: 10,
            paddingLeft: 20,
            paddingRight: 20,
            marginBottom: 28,
          }}
        >
          {goals.map((g, i) => {
            const selected = selectedGoal === g.id;
            return (
              <motion.button
                key={g.id}
                initial={{ opacity: 0, scale: 0.94 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.06 + 0.1 }}
                whileTap={{ scale: 0.96 }}
                onClick={() => setSelectedGoal(selected ? null : g.id)}
                style={{
                  background: selected ? g.bg : colors.white,
                  border: `2px solid ${selected ? g.accent : colors.gray200}`,
                  borderRadius: 18,
                  padding: "16px 14px",
                  textAlign: "left",
                  cursor: "pointer",
                  boxShadow: selected ? `0 4px 16px ${g.accent}30` : shadow.sm,
                  transition: "all 0.18s ease",
                  position: "relative",
                }}
              >
                {selected && (
                  <div
                    style={{
                      position: "absolute",
                      top: 10,
                      right: 10,
                      width: 20,
                      height: 20,
                      borderRadius: 99,
                      background: g.accent,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <span style={{ color: colors.white, fontSize: 11, fontWeight: 800 }}>✓</span>
                  </div>
                )}
                <div style={{ fontSize: 28, marginBottom: 8 }}>{g.emoji}</div>
                <p style={{ fontSize: 14, fontWeight: 700, color: colors.black, marginBottom: 3 }}>
                  {g.title}
                </p>
                <p style={{ fontSize: 11, color: colors.gray600, lineHeight: 1.4 }}>{g.subtitle}</p>
              </motion.button>
            );
          })}
        </div>

        {/* Fitness level */}
        <div style={{ paddingLeft: 20, paddingRight: 20, marginBottom: 24 }}>
          <p style={{ fontSize: 16, fontWeight: 700, color: colors.black, marginBottom: 12 }}>
            What's your fitness level?
          </p>
          <div style={{ display: "flex", gap: 8 }}>
            {fitnessLevels.map((l) => {
              const sel = level === l.id;
              return (
                <button
                  key={l.id}
                  onClick={() => setLevel(l.id)}
                  style={{
                    flex: 1,
                    height: 64,
                    borderRadius: 14,
                    border: `2px solid ${sel ? colors.primary : colors.gray200}`,
                    background: sel ? colors.primaryLight : colors.white,
                    cursor: "pointer",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: 2,
                    transition: "all 0.15s ease",
                  }}
                >
                  <span style={{ fontSize: 13, fontWeight: 700, color: sel ? colors.primary : colors.black }}>
                    {l.label}
                  </span>
                  <span style={{ fontSize: 10, color: colors.gray400 }}>{l.sub}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Days per week */}
        <div style={{ paddingLeft: 20, paddingRight: 20, marginBottom: 16 }}>
          <p style={{ fontSize: 16, fontWeight: 700, color: colors.black, marginBottom: 12 }}>
            Days per week
          </p>
          <div style={{ display: "flex", gap: 8 }}>
            {daysPerWeek.map((d) => {
              const sel = days === d;
              return (
                <button
                  key={d}
                  onClick={() => setDays(d)}
                  style={{
                    flex: 1,
                    height: 48,
                    borderRadius: 12,
                    border: `2px solid ${sel ? colors.primary : colors.gray200}`,
                    background: sel ? colors.primary : colors.white,
                    color: sel ? colors.white : colors.black,
                    fontSize: 15,
                    fontWeight: 700,
                    cursor: "pointer",
                    transition: "all 0.15s ease",
                  }}
                >
                  {d}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Fixed CTA */}
      <div
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          padding: "16px 24px 20px",
          background: "linear-gradient(to top, white 70%, transparent)",
        }}
      >
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={canContinue ? onNext : undefined}
          style={{
            width: "100%",
            height: 56,
            borderRadius: 16,
            background: canContinue ? colors.primary : colors.gray200,
            color: canContinue ? colors.white : colors.gray400,
            fontSize: 17,
            fontWeight: 700,
            border: "none",
            cursor: canContinue ? "pointer" : "default",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            boxShadow: canContinue ? shadow.primary : "none",
            transition: "all 0.2s ease",
          }}
        >
          Build my plan <ChevronRight size={20} />
        </motion.button>
      </div>
    </div>
  );
}
