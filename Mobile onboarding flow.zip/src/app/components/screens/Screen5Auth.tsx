import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { colors, shadow, transition } from "../ds";
import { Eye, EyeOff, Mail, Lock, User, ChevronRight, ArrowLeft } from "lucide-react";

interface Props {
  onSignUp: () => void;
  onBack: () => void;
}

type Mode = "signup" | "login";

function SocialButton({ emoji, label }: { emoji: string; label: string }) {
  return (
    <button
      style={{
        flex: 1,
        height: 50,
        borderRadius: 14,
        background: colors.white,
        border: `1.5px solid ${colors.gray200}`,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 8,
        cursor: "pointer",
        boxShadow: shadow.sm,
      }}
    >
      <span style={{ fontSize: 18 }}>{emoji}</span>
      <span style={{ fontSize: 14, fontWeight: 600, color: colors.gray800 }}>{label}</span>
    </button>
  );
}

function InputField({
  icon: Icon,
  placeholder,
  type = "text",
  value,
  onChange,
  trailing,
}: {
  icon: React.ElementType;
  placeholder: string;
  type?: string;
  value: string;
  onChange: (v: string) => void;
  trailing?: React.ReactNode;
}) {
  return (
    <div
      style={{
        height: 54,
        borderRadius: 14,
        background: colors.gray100,
        border: `1.5px solid ${colors.gray200}`,
        display: "flex",
        alignItems: "center",
        paddingLeft: 16,
        paddingRight: 14,
        gap: 12,
      }}
    >
      <Icon size={18} color={colors.gray400} style={{ flexShrink: 0 }} />
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        style={{
          flex: 1,
          background: "transparent",
          border: "none",
          outline: "none",
          fontSize: 15,
          color: colors.black,
          fontFamily: "inherit",
        }}
      />
      {trailing}
    </div>
  );
}

export function Screen5Auth({ onSignUp, onBack }: Props) {
  const [mode, setMode] = useState<Mode>("signup");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);

  return (
    <div className="flex flex-col h-full" style={{ background: colors.white }}>
      {/* Top */}
      <div className="flex items-center px-6 pt-4 pb-2 shrink-0">
        <button
          onClick={onBack}
          style={{
            width: 36,
            height: 36,
            borderRadius: 10,
            background: colors.gray100,
            border: "none",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            cursor: "pointer",
          }}
        >
          <ArrowLeft size={18} color={colors.gray800} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-6 pb-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          style={{ marginBottom: 28, marginTop: 8 }}
        >
          <div style={{ fontSize: 36, marginBottom: 12 }}>👋</div>
          <h2
            style={{
              fontSize: 30,
              fontWeight: 800,
              color: colors.black,
              lineHeight: 1.15,
              letterSpacing: "-0.025em",
              marginBottom: 8,
            }}
          >
            {mode === "signup" ? "Create your account" : "Welcome back"}
          </h2>
          <p style={{ color: colors.gray600, fontSize: 15, lineHeight: 1.55 }}>
            {mode === "signup"
              ? "Start your fitness journey in seconds."
              : "Log in and pick up where you left off."}
          </p>
        </motion.div>

        {/* Mode toggle */}
        <div
          style={{
            display: "flex",
            background: colors.gray100,
            borderRadius: 14,
            padding: 4,
            marginBottom: 24,
            position: "relative",
          }}
        >
          {(["signup", "login"] as Mode[]).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              style={{
                flex: 1,
                height: 40,
                borderRadius: 11,
                border: "none",
                cursor: "pointer",
                fontSize: 14,
                fontWeight: 700,
                position: "relative",
                zIndex: 1,
                background: mode === m ? colors.white : "transparent",
                color: mode === m ? colors.black : colors.gray400,
                boxShadow: mode === m ? shadow.sm : "none",
                transition: "all 0.18s ease",
              }}
            >
              {m === "signup" ? "Sign Up" : "Log In"}
            </button>
          ))}
        </div>

        {/* Form fields */}
        <AnimatePresence mode="wait">
          <motion.div
            key={mode}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={transition.ease}
          >
            <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 20 }}>
              {mode === "signup" && (
                <InputField
                  icon={User}
                  placeholder="Full name"
                  value={name}
                  onChange={setName}
                />
              )}
              <InputField
                icon={Mail}
                placeholder="Email address"
                type="email"
                value={email}
                onChange={setEmail}
              />
              <InputField
                icon={Lock}
                placeholder="Password"
                type={showPw ? "text" : "password"}
                value={password}
                onChange={setPassword}
                trailing={
                  <button
                    onClick={() => setShowPw((v) => !v)}
                    style={{ background: "none", border: "none", cursor: "pointer", padding: 2 }}
                  >
                    {showPw ? (
                      <EyeOff size={18} color={colors.gray400} />
                    ) : (
                      <Eye size={18} color={colors.gray400} />
                    )}
                  </button>
                }
              />
            </div>

            {mode === "login" && (
              <button
                style={{
                  background: "none",
                  border: "none",
                  color: colors.primary,
                  fontSize: 14,
                  fontWeight: 600,
                  cursor: "pointer",
                  marginBottom: 20,
                  display: "block",
                }}
              >
                Forgot password?
              </button>
            )}
          </motion.div>
        </AnimatePresence>

        {/* Primary CTA */}
        <button
          onClick={onSignUp}
          style={{
            width: "100%",
            height: 56,
            borderRadius: 16,
            background: colors.primary,
            color: colors.white,
            fontSize: 17,
            fontWeight: 700,
            border: "none",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            boxShadow: shadow.primary,
            marginBottom: 20,
          }}
        >
          {mode === "signup" ? "Create account" : "Log in"}
          <ChevronRight size={20} />
        </button>

        {/* Divider */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 12,
            marginBottom: 20,
          }}
        >
          <div style={{ flex: 1, height: 1, background: colors.gray200 }} />
          <span style={{ color: colors.gray400, fontSize: 13, fontWeight: 500 }}>or continue with</span>
          <div style={{ flex: 1, height: 1, background: colors.gray200 }} />
        </div>

        {/* Social auth */}
        <div style={{ display: "flex", gap: 10, marginBottom: 24 }}>
          <SocialButton emoji="🍎" label="Apple" />
          <SocialButton emoji="G" label="Google" />
        </div>

        {/* Legal */}
        <p style={{ color: colors.gray400, fontSize: 12, textAlign: "center", lineHeight: 1.6 }}>
          By continuing, you agree to our{" "}
          <span style={{ color: colors.gray600, fontWeight: 600 }}>Terms of Service</span> and{" "}
          <span style={{ color: colors.gray600, fontWeight: 600 }}>Privacy Policy</span>
        </p>
      </div>
    </div>
  );
}
