import { useState } from "react";
import { motion } from "motion/react";
import { colors, shadow, transition } from "../ds";
import {
  Activity,
  Flame,
  Dumbbell,
  Play,
  Plus,
  Home,
  BarChart2,
  Calendar,
  User,
  TrendingUp,
  ChevronRight,
  Clock,
  Zap,
} from "lucide-react";

interface Props {
  onRestart: () => void;
}

const todayStats = [
  { icon: Flame, label: "Calories", value: "1,240", unit: "kcal", color: colors.primary, bg: colors.primaryLight },
  { icon: Activity, label: "Active time", value: "42", unit: "min", color: "#3B82F6", bg: "#EFF6FF" },
  { icon: Zap, label: "Steps", value: "6,841", unit: "", color: "#22C55E", bg: "#F0FDF4" },
];

const suggestedWorkouts = [
  {
    title: "Morning HIIT",
    duration: "25 min",
    cal: "320 cal",
    level: "Intermediate",
    emoji: "⚡",
    bg: "linear-gradient(135deg, #ff4d00 0%, #ff8c5a 100%)",
    light: false,
  },
  {
    title: "Upper Body Strength",
    duration: "40 min",
    cal: "280 cal",
    level: "All levels",
    emoji: "💪",
    bg: "linear-gradient(135deg, #1e3a5f 0%, #3B82F6 100%)",
    light: false,
  },
];

const recentActivity = [
  { emoji: "🏃", title: "5K Run", meta: "Yesterday · 5.2 km · 38 min", cal: "420 cal", trending: true },
  { emoji: "🏋️", title: "Chest & Back", meta: "2 days ago · 8 exercises", cal: "290 cal", trending: false },
  { emoji: "🚴", title: "Cycling ride", meta: "3 days ago · 18.4 km", cal: "510 cal", trending: false },
];

const streakDays = ["M", "T", "W", "T", "F", "S", "S"];
const streakDone = [true, true, true, true, false, false, false];

function BottomNavItem({
  icon: Icon,
  label,
  active,
}: {
  icon: React.ElementType;
  label: string;
  active?: boolean;
}) {
  return (
    <button
      style={{
        flex: 1,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 3,
        paddingTop: 8,
        paddingBottom: 4,
        background: "none",
        border: "none",
        cursor: "pointer",
      }}
    >
      <Icon
        size={22}
        color={active ? colors.primary : colors.gray400}
        strokeWidth={active ? 2.2 : 1.8}
      />
      <span
        style={{
          fontSize: 10,
          fontWeight: active ? 700 : 500,
          color: active ? colors.primary : colors.gray400,
        }}
      >
        {label}
      </span>
      {active && (
        <div
          style={{ width: 4, height: 4, borderRadius: 99, background: colors.primary, marginTop: -1 }}
        />
      )}
    </button>
  );
}

export function Screen7Dashboard({ onRestart }: Props) {
  const [activeTab, setActiveTab] = useState("home");

  return (
    <div className="flex flex-col h-full" style={{ background: colors.gray100 }}>
      {/* Scrollable content */}
      <div className="flex-1 overflow-y-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          style={{
            background: colors.white,
            paddingLeft: 24,
            paddingRight: 24,
            paddingTop: 12,
            paddingBottom: 20,
            marginBottom: 12,
          }}
        >
          <div className="flex items-center justify-between" style={{ marginBottom: 16 }}>
            <div>
              <p style={{ color: colors.gray600, fontSize: 13, fontWeight: 500, marginBottom: 2 }}>
                Good morning 👋
              </p>
              <h2
                style={{
                  fontSize: 24,
                  fontWeight: 800,
                  color: colors.black,
                  letterSpacing: "-0.02em",
                  lineHeight: 1.2,
                }}
              >
                Jordan Smith
              </h2>
            </div>
            <div
              style={{
                width: 46,
                height: 46,
                borderRadius: 14,
                background: colors.primaryLight,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 22,
                boxShadow: shadow.sm,
              }}
            >
              🏃
            </div>
          </div>

          {/* Streak tracker */}
          <div
            style={{
              background: colors.black,
              borderRadius: 18,
              padding: "14px 18px",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <div>
              <p style={{ color: "rgba(255,255,255,0.55)", fontSize: 11, fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 2 }}>
                Current streak
              </p>
              <div className="flex items-baseline gap-1">
                <span style={{ color: colors.white, fontSize: 26, fontWeight: 800, letterSpacing: "-0.02em" }}>14</span>
                <span style={{ color: "rgba(255,255,255,0.5)", fontSize: 13 }}>days 🔥</span>
              </div>
            </div>
            <div className="flex gap-2">
              {streakDays.map((d, i) => (
                <div key={i} className="flex flex-col items-center gap-1">
                  <div
                    style={{
                      width: 26,
                      height: 26,
                      borderRadius: 8,
                      background: streakDone[i] ? colors.primary : "rgba(255,255,255,0.1)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    {streakDone[i] && (
                      <span style={{ color: colors.white, fontSize: 12, fontWeight: 800 }}>✓</span>
                    )}
                  </div>
                  <span style={{ color: "rgba(255,255,255,0.35)", fontSize: 9, fontWeight: 600 }}>{d}</span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Today's stats */}
        <div style={{ paddingLeft: 20, paddingRight: 20, marginBottom: 16 }}>
          <div className="flex items-center justify-between" style={{ marginBottom: 12 }}>
            <p style={{ fontSize: 16, fontWeight: 800, color: colors.black }}>Today's activity</p>
            <span style={{ fontSize: 12, color: colors.gray400 }}>Sun, Jun 14</span>
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            {todayStats.map((s, i) => (
              <motion.div
                key={s.label}
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 + 0.15 }}
                style={{
                  flex: 1,
                  background: s.bg,
                  borderRadius: 16,
                  padding: "14px 12px",
                }}
              >
                <s.icon size={16} color={s.color} style={{ marginBottom: 6 }} />
                <p style={{ fontSize: 18, fontWeight: 800, color: colors.black, lineHeight: 1 }}>
                  {s.value}
                  {s.unit && (
                    <span style={{ fontSize: 10, fontWeight: 500, color: colors.gray600, marginLeft: 2 }}>
                      {s.unit}
                    </span>
                  )}
                </p>
                <p style={{ fontSize: 10, color: colors.gray600, marginTop: 3 }}>{s.label}</p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Suggested workouts */}
        <div style={{ paddingLeft: 20, paddingRight: 20, marginBottom: 16 }}>
          <div className="flex items-center justify-between" style={{ marginBottom: 12 }}>
            <p style={{ fontSize: 16, fontWeight: 800, color: colors.black }}>Suggested for you</p>
            <button style={{ background: "none", border: "none", color: colors.primary, fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
              See all
            </button>
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            {suggestedWorkouts.map((w, i) => (
              <motion.div
                key={w.title}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 + 0.2 }}
                style={{
                  flex: 1,
                  background: w.bg,
                  borderRadius: 20,
                  padding: 16,
                  position: "relative",
                  overflow: "hidden",
                  minHeight: 140,
                }}
              >
                <div
                  style={{
                    position: "absolute",
                    width: 80,
                    height: 80,
                    borderRadius: "50%",
                    background: "rgba(255,255,255,0.1)",
                    top: -20,
                    right: -20,
                  }}
                />
                <span style={{ fontSize: 28, display: "block", marginBottom: 10 }}>{w.emoji}</span>
                <p style={{ color: colors.white, fontSize: 14, fontWeight: 800, marginBottom: 4, lineHeight: 1.2 }}>
                  {w.title}
                </p>
                <p style={{ color: "rgba(255,255,255,0.65)", fontSize: 11 }}>{w.duration}</p>
                <p style={{ color: "rgba(255,255,255,0.65)", fontSize: 11 }}>{w.cal}</p>
                <button
                  style={{
                    marginTop: 10,
                    width: 32,
                    height: 32,
                    borderRadius: 99,
                    background: "rgba(255,255,255,0.2)",
                    border: "none",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: "pointer",
                  }}
                >
                  <Play size={14} color={colors.white} fill={colors.white} />
                </button>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Recent activity */}
        <div style={{ paddingLeft: 20, paddingRight: 20, marginBottom: 16 }}>
          <div className="flex items-center justify-between" style={{ marginBottom: 12 }}>
            <p style={{ fontSize: 16, fontWeight: 800, color: colors.black }}>Recent activity</p>
            <button style={{ background: "none", border: "none", color: colors.primary, fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
              View all
            </button>
          </div>
          <div
            style={{
              background: colors.white,
              borderRadius: 20,
              overflow: "hidden",
              boxShadow: shadow.sm,
            }}
          >
            {recentActivity.map((a, i) => (
              <motion.div
                key={a.title}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: i * 0.07 + 0.3 }}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 14,
                  padding: "14px 18px",
                  borderBottom: i < recentActivity.length - 1 ? `1px solid ${colors.gray100}` : "none",
                }}
              >
                <div
                  style={{
                    width: 44,
                    height: 44,
                    borderRadius: 12,
                    background: colors.gray100,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: 20,
                    flexShrink: 0,
                  }}
                >
                  {a.emoji}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ fontWeight: 700, color: colors.black, fontSize: 14 }}>{a.title}</p>
                  <p style={{ color: colors.gray400, fontSize: 11, marginTop: 1 }}>{a.meta}</p>
                </div>
                <div style={{ textAlign: "right" }}>
                  <p style={{ fontWeight: 700, color: colors.primary, fontSize: 13 }}>{a.cal}</p>
                  {a.trending && (
                    <div className="flex items-center gap-1" style={{ justifyContent: "flex-end" }}>
                      <TrendingUp size={10} color="#22C55E" />
                      <span style={{ fontSize: 10, color: "#22C55E", fontWeight: 600 }}>PR</span>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Restart link */}
        <div style={{ paddingLeft: 20, paddingRight: 20, paddingBottom: 20, textAlign: "center" }}>
          <button
            onClick={onRestart}
            style={{ background: "none", border: "none", color: colors.gray400, fontSize: 12, cursor: "pointer" }}
          >
            ← Restart onboarding
          </button>
        </div>
      </div>

      {/* Bottom navigation */}
      <motion.div
        initial={{ y: 60, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4, ...transition.spring }}
        style={{
          background: colors.white,
          borderTop: `1px solid ${colors.gray100}`,
          display: "flex",
          paddingBottom: 4,
          boxShadow: "0 -4px 20px rgba(0,0,0,0.05)",
          flexShrink: 0,
        }}
      >
        <BottomNavItem icon={Home} label="Home" active={activeTab === "home"} />
        <BottomNavItem icon={Activity} label="Workouts" active={activeTab === "workouts"} />
        <button
          style={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            paddingTop: 6,
            background: "none",
            border: "none",
            cursor: "pointer",
          }}
        >
          <div
            style={{
              width: 46,
              height: 46,
              borderRadius: 14,
              background: colors.primary,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: shadow.primarySm,
              marginTop: -14,
            }}
          >
            <Plus size={22} color={colors.white} strokeWidth={2.5} />
          </div>
          <span style={{ fontSize: 10, fontWeight: 500, color: colors.gray400, marginTop: 3 }}>Log</span>
        </button>
        <BottomNavItem icon={BarChart2} label="Progress" active={activeTab === "progress"} />
        <BottomNavItem icon={User} label="Profile" active={activeTab === "profile"} />
      </motion.div>
    </div>
  );
}
