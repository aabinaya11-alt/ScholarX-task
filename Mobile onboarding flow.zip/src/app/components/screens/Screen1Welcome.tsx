import { motion } from "motion/react";
import { colors, shadow, transition } from "../ds";
import { ChevronRight } from "lucide-react";

interface Props {
  onGetStarted: () => void;
  onLogin: () => void;
}

const STAT_PILLS = [
  { label: "Active users", value: "2.4M+" },
  { label: "Workouts logged", value: "180M" },
  { label: "App Store", value: "4.9 ★" },
];

export function Screen1Welcome({ onGetStarted, onLogin }: Props) {
  return (
    <div className="flex flex-col h-full relative overflow-hidden">
      {/* Hero gradient background */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(170deg, #1a0800 0%, #2d1000 30%, #ff4d00 72%, #ff8c5a 100%)",
        }}
      />

      {/* Ambient glow blobs */}
      <div
        className="absolute"
        style={{
          width: 320,
          height: 320,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(255,77,0,0.4) 0%, transparent 70%)",
          top: -80,
          right: -80,
        }}
      />
      <div
        className="absolute"
        style={{
          width: 240,
          height: 240,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(255,140,90,0.25) 0%, transparent 70%)",
          bottom: 200,
          left: -60,
        }}
      />

      {/* Top — Logo */}
      <motion.div
        initial={{ opacity: 0, y: -16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, ...transition.ease }}
        className="relative z-10 flex items-center gap-3 px-7 pt-4"
      >
        <div
          style={{
            width: 40,
            height: 40,
            borderRadius: 12,
            background: "rgba(255,255,255,0.15)",
            backdropFilter: "blur(8px)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 20,
          }}
        >
          🔥
        </div>
        <span
          style={{
            color: colors.white,
            fontSize: 20,
            fontWeight: 800,
            letterSpacing: "-0.02em",
          }}
        >
          FitTrack
        </span>
      </motion.div>

      {/* Center — Hero content */}
      <div className="relative z-10 flex-1 flex flex-col justify-end px-7 pb-6">
        {/* Athlete emoji / illustration */}
        <motion.div
          initial={{ scale: 0.6, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 18, delay: 0.15 }}
          style={{ fontSize: 100, lineHeight: 1, textAlign: "center", marginBottom: 32 }}
        >
          🏃‍♂️
        </motion.div>

        {/* Headline */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25, ...transition.ease }}
          style={{ marginBottom: 14 }}
        >
          <p
            style={{
              color: "rgba(255,255,255,0.65)",
              fontSize: 13,
              fontWeight: 600,
              letterSpacing: "0.1em",
              textTransform: "uppercase",
              marginBottom: 10,
            }}
          >
            Your fitness journey starts here
          </p>
          <h1
            style={{
              color: colors.white,
              fontSize: 40,
              fontWeight: 800,
              lineHeight: 1.1,
              letterSpacing: "-0.03em",
            }}
          >
            Train smarter.{"\n"}Live stronger.
          </h1>
        </motion.div>

        {/* Body copy */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.35 }}
          style={{
            color: "rgba(255,255,255,0.65)",
            fontSize: 15,
            lineHeight: 1.6,
            marginBottom: 28,
          }}
        >
          Track workouts, follow personalized plans, and hit every goal — all in one place.
        </motion.p>

        {/* Stat pills */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.45 }}
          className="flex gap-2 mb-8 flex-wrap"
        >
          {STAT_PILLS.map((s) => (
            <div
              key={s.label}
              style={{
                background: "rgba(255,255,255,0.12)",
                backdropFilter: "blur(8px)",
                borderRadius: 99,
                paddingLeft: 12,
                paddingRight: 12,
                paddingTop: 6,
                paddingBottom: 6,
                border: "1px solid rgba(255,255,255,0.18)",
              }}
            >
              <span style={{ color: colors.white, fontSize: 13, fontWeight: 700 }}>{s.value}</span>
              <span style={{ color: "rgba(255,255,255,0.55)", fontSize: 12, marginLeft: 5 }}>{s.label}</span>
            </div>
          ))}
        </motion.div>

        {/* Bottom sheet card */}
        <motion.div
          initial={{ opacity: 0, y: 32 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, ...transition.spring }}
          style={{
            background: colors.white,
            borderRadius: 28,
            padding: 24,
            boxShadow: shadow.lg,
          }}
        >
          {/* Primary CTA */}
          <button
            onClick={onGetStarted}
            style={{
              width: "100%",
              height: 56,
              borderRadius: 16,
              background: colors.primary,
              color: colors.white,
              fontSize: 17,
              fontWeight: 700,
              border: "none",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
              boxShadow: shadow.primary,
              marginBottom: 14,
            }}
          >
            Get Started <ChevronRight size={20} />
          </button>

          {/* Secondary */}
          <button
            onClick={onLogin}
            style={{
              width: "100%",
              height: 48,
              borderRadius: 14,
              background: "transparent",
              color: colors.gray600,
              fontSize: 15,
              fontWeight: 600,
              border: "none",
              cursor: "pointer",
            }}
          >
            Already have an account?{" "}
            <span style={{ color: colors.primary }}>Log in</span>
          </button>
        </motion.div>
      </div>
    </div>
  );
}
